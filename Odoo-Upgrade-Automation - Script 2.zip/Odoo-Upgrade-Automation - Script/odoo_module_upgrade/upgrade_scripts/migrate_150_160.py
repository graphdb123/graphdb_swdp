from odoo_module_upgrade.base_migration_script import BaseMigrationScript


class MigrationScript(BaseMigrationScript):
    pass
