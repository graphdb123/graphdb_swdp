
class OdooMigrateException(Exception):
    pass


class ConfigException(OdooMigrateException):
    pass
